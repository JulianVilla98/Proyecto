
<?php require 'index.html'?>
<html>


<body>
    <link rel="stylesheet" href="assets/css/style1.css" />
<div id="events" class="tab-pane fade">
				<h1>Eventos</h1>
				<div class="media">
					<div class="media-left">
                        
                            <h4 class="media-heading">Vicerrectoría Campus NG <small><i>Publicado el 15 de Mayo, 2021</i></small></h4>
							Respetada Comunidad Neogranadina,
La División de Medio Universitario y el área deportiva de Bienestar Universitario Campus los invitan a participar en la siguiente actividad:
						
						<img src="torneo tenis de mesa.png" class="media-object" style="width:800px">
					</div>
					<div class="media-body">
						
						
						<!-- Nested media object -->
						<div class="media">
							<div class="media-left">
                                	<div class="media-body">
								<h4 class="media-heading">División Medio Universitario Campus <small><i>Publicado el 27 de Mayo, 2021</i></small></h4>
								
							</div>
                                <p>Respetada comunidad neogranadina,
La División de Medio Universitario  invita a disfrutar en familia del  Encuentro Internacional de Poesía. </p>
								<img src="poesia.jpg" class="media-object" style="width:800px">
							</div>
						
						</div>
					</div>
				</div>
</div>
</body>
</html>